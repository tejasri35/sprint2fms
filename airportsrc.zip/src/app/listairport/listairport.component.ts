import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { Airport } from 'src/airport';
import { airportService } from '../airportservice.service';

@Component({
  selector: 'app-listairport',
  templateUrl: './listairport.component.html',
  styleUrls: ['./listairport.component.css']
})
export class ListairportComponent implements OnInit {

  
  flag: boolean = false;
  arr1: Observable<Airport[]>;
  airport : Airport = new Airport();
  temp: Airport=new Airport();
  constructor(private service : airportService,
    private router: Router) {
      

    }

  ngOnInit() {
    this.arr1=this.service.getAllAirports();
  }
 
  reloadData() {
    this.arr1=this.service.getAllAirports();
   this.view();
  }

  
 view(){
  this.router.navigate(['view']);
  }


  addAirport(){
    this.router.navigate(['add']);
  }

  update(id){

    this.router.navigate(['update',id]);
  }
  
  deleteAirport(acode: number){
    
    this.service.deleteAirportById(acode).subscribe(data => {console.log(data);this.reloadData();},error => console.log(error));
    this.reloadData();
  }
}