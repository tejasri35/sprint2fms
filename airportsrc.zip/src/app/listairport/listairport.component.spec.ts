import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListairportComponent } from './listairport.component';

describe('ListairportComponent', () => {
  let component: ListairportComponent;
  let fixture: ComponentFixture<ListairportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListairportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListairportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
