import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Airport } from 'src/airport';
import { airportService } from '../airportservice.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  id: number;
  submitted = false;
  airport : Airport ;
  constructor(private service : airportService,
    private router: Router , private route : ActivatedRoute) {
      

    }

  ngOnInit() {

    this.airport= new Airport();

    this.id = this.route.snapshot.params['id'];

    this.service.findByairportId(this.id).subscribe(data => {console.log(data) , this.airport= data; }, error => console.log(error));
    
  }
 
 view(){
  this.router.navigate(['view']);
  }

  updateairportById()
  {
    console.log(this.airport);
    this.service.updateairportById(this.airport).subscribe(data => console.log(data), error => console.log(error));
    this.airport = new Airport();
    this.view();
  }
  onSubmit() {
    this.updateairportById();
    this.submitted = true;
  }


  
 
}