import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Airport } from 'src/airport';
import { Login } from './login';


@Injectable({
  providedIn: 'root'
})
export class airportService {
  

url="http://localhost:9090/airport";

  constructor(private http:HttpClient) { }
  
 findUserLogin(username: string,password :string) : Observable<Login>{
  return this.http.get<Login >("http://localhost:9090/admin/login/"+username+"/"+password);
}

  addairport(airport : Airport ) : Observable<Airport>
  {
    console.log("Service : "+airport.acode);
    return this.http.post<Airport>("http://localhost:9090/airport/",airport);
  }

  getAllAirports() : Observable<Airport[]>
  {
      return this.http.get<Airport[]>(`${this.url}`);
  }

deleteAirportById(acode:number) : Observable<Airport>
{
  console.log(" Id = "+acode);
  return this.http.delete<Airport>("http://localhost:9090/airport/"+acode);

}
updateairportById(airport:Airport): Observable<Airport> {
  return this.http.put<Airport>(`${this.url}`, airport);

}
findByairportId(acode : number) : Observable<Airport>
  {
    console.log(" Id = "+acode);
    return this.http.get<Airport>("http://localhost:9090/airport/"+acode);
  }

}
