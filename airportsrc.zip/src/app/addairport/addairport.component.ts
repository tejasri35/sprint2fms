import { Component, OnInit } from '@angular/core';

import { Observable } from 'rxjs';

import { Router } from '@angular/router';
import { Airport } from 'src/airport';
import { airportService } from '../airportservice.service';

@Component({
  selector: 'app-addairport',
  templateUrl: './addairport.component.html',
  styleUrls: ['./addairport.component.css']
})
export class AddairportComponent implements OnInit {

  arr1: Observable<Airport[]>;
  airport : Airport = new Airport();
  submitted = false;

  constructor(private airportService: airportService,
    private router: Router) { }

  ngOnInit() {
    
  }

  newAirport(): void {
    this.submitted = false;
    this.airport = new Airport();
  }

  save() {
    this.airportService.addairport(this.airport).subscribe(data => console.log(data), error => console.log(error));
    this.airport = new Airport();
    this.reloadData();
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }
  reloadData() {
    this.arr1 = this.airportService.getAllAirports();
    this.gotoList();
   }
  gotoList() {
    this.router.navigate(['view']);
  }

}