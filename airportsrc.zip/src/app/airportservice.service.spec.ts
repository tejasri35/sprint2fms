import { TestBed } from '@angular/core/testing';
import { airportService } from './airportservice.service';





describe('airportService', () => {
  let service: airportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(airportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
