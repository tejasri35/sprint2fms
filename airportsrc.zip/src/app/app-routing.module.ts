import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddairportComponent } from './addairport/addairport.component';
import { ListairportComponent } from './listairport/listairport.component';
import { UpdateComponent } from './update/update.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
{
  path :'add',
  component: AddairportComponent
},
{
  path: 'view',
  component: ListairportComponent
},
{
  
    path : 'update/:id',
    component : UpdateComponent
  },
  {
  path : '',
  redirectTo : '/view',
  pathMatch : 'full'
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
