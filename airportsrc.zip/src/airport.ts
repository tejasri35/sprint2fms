export class Airport
{
acode:number;
aname:string;
alocation:string;

}